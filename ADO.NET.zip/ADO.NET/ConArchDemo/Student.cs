﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConArchDemo
{
    public class Student
    {
        public int RollNo { get; set; }
        public string Name{ get; set; }

        public int Age { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }

    }
}
